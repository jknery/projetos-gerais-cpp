see http://www.rainemu.com/ for docs in html, pdf and ascii format.

/****************************************************************/
/*                          JOGO NAVE (1.0)                     */
/* Este jogo e freeware mas nao se deve alterar o seu conteudo  */
/* a fins comerciais.                                           */
/* Produtor: Mario Fontes 06/01/98                              */
/****************************************************************/


//========================== INCLUDES ============================
#include <iostream>
#include <windows.h>
#include <conio.h>
#include <dos.h>
#include <stdlib.h>
#include <stdio.h>
using namespace std;
//================================================================

void gotoxy (int x, int y)
{

COORD coord;
coord.X = x;
coord.Y = y;

SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%% GLOBAIS %%%%%%%%%%%%%%%%%%%%%%%%%%%%

 /* Variavel global para sair com ESCAPE */
const char ESC = 27;

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



//--------------------Descricao das Funcoes-----------------------

 //Funcao para posicionar a nave
void posicao(int posnave,int car_nav);

 //Funcao para mandar o tiro
void tiro(int op,int car_nav, int car_tiro);

 //Funcao para o dezenho da barra do menu
void instrucoes();

 //Funcao para desenhar os alvos
void alvos(int quantidade);

 //Funcao para limpar a posisao antiga da nave
void limpapos(int p);

 //Funcao para contar o numero de passos
void contpas(int a,int cont_rest);

 //Funcao de introducao
void intro();

 //Funcao para restaurar o jogo
void restaura(int a,int dificuldade,int car_nav, int cont_rest);

 //Funcao de som do movimento
void som_mov(int inicio,int fim);

 //Funcao para obtencao de dificuldade
int esc_dificuldade();

 //Funcao para o numero de tiros
int defini_tiros(int dificuldade);

 //Funcao para a definicao do tipo de nave
int def_nave();

 //Funcao para a definicao do tipo de tiro
int def_tiro();

//----------------------------------------------------------------



//----------------------Programa Principal------------------------
int main()
{
  Repetir_programa:

 //\\\\\\\\\\\\\\\\\\\\\\\\\ VARIAVEIS ///////////////////////////

  /* Variavel para o caracter da nave e do tiro */
  int car_nav,car_tiro;

  /* Variavel para contar o numero de restauracoes */
  int cont_rest=4;

  /* Variavel para o TIRO */
  int a;

  /* Variavel de opcao */
  int op,resp;

  /* Variaveis para definicao do som de movimentacao */
  int inicio,fim;

  /* Variavel para a definicao da posicao inicial da nave */
  int posnave=40;

  /* Variavel da dificuldade */
  int dificuldade;

 //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/////////////////////////////////

  /* Limpa a tela */
  system("cls");

  /* Introducao */
  intro();

  /* Escolha da dificuldade */
  dificuldade=esc_dificuldade();

  /* Escolha da nave */
  car_nav=def_nave();

  /* Escolha do tiro */
  car_tiro=def_tiro();

  /* Limpa a tela */
  system("cls");

  a=defini_tiros(dificuldade);

  /* Impresao dos alvos na tela */
  alvos(dificuldade);

  /* Tiros utilizados (START) */
  contpas(a,cont_rest);

  /* Menu das intrucoes */
  instrucoes();

  /* START DA NAVE */
  posicao(posnave,car_nav);

  /* Limpesa de posicao inicial */
  gotoxy (64,23);
  printf (" ");
  gotoxy (64,23);

  /* Decisoes de movimento */
  do{

	 /* primeira obtencao da tecla */
	 op=getch();

	  /* Verificacao se e' tecla do tipo especial */
	  if (op==0)
	  {

	   /* segunda obtencao da tecla */
	   op=getch();

	   /* Movimento para a esquerda */
	   if (op==75) {
					/* Limpesa da posicao anterior */
					limpapos(posnave);

					/* Decrecimo de posicao */
					posnave=posnave-1;

					/* Acerto limite 'a esquerda */
					if (posnave<1) posnave=80;

					/* Imprime posicao */
					posicao(posnave,car_nav);

					/* Define som de movimento */
					inicio=10;
					fim=100;

					/* Saida do som */
					som_mov(inicio,fim);
				   }

	   /* Movimento para a direita */
	   if (op==77) {
					/* Limpesa da posicao anterior */
					limpapos(posnave);

					/* Acrecimo de posicao */
					posnave=posnave+1;

					/* Acerto limite 'a direita */
					if (posnave>80) posnave=1;

					/* Imprime posicao */
					posicao(posnave,car_nav);

					/* Define som de movimento */
					inicio=10;
					fim=100;

					/* Saida do som */
					som_mov(inicio,fim);
				   }

	   /* Movimento do tiro */
	   if (op==72) {

					/* Decrecimo dos tiros */
					a--;

					/* IF para nao imprimir (-1) */
					if (a!=(-1))
					{
					 /* Atualizacao dos tiros */
					 contpas(a,cont_rest);

					 /* Animacao do tiro */
					 tiro(posnave,car_nav,car_tiro);
					}

				   }

	   /* Movimento a restauracao */
	   if (op==80) {
					/* Decrecimo nas restauracoes */
					cont_rest--;

					/* Redefine a posicao da nave */
					posnave=40;

					/* Redefine a quantidade de tiros */
					a=defini_tiros(dificuldade);

					/* RESTAURACAO */

					 /* IF para garantir a nao impresao de (-1) */
					if (cont_rest!=(-1))
					restaura(a,dificuldade,car_nav,cont_rest);

					/* Define som de movimento */
					inicio=3000;
					fim=6000;

					/* Saida do som */
					som_mov(inicio,fim);
				   }
	  }

	 /* IF para quando acaba os tiros */
	 if (a==(-1)) {

		   /* Limpesa da tela */
		   system("cls");

		   /* Definicao de cor */
		   textcolor(12+BLINK);

		   /* Mensagem */
		   gotoxy(13,10);
		   printf("Acabram-se os TIROS e os invasores invadiram a Terra !!");

		   /* Pergunta para rejogar */
		   textcolor(15);
		   gotoxy(20,14);
		   printf("Deseja jogar novamente ? (s/SIM ou n/NAO)");

		   /* Ponto de falha na opcao */
		   repeteco:

		   /* Captura da resposta */
		   resp=getch();

		   /* Verificacao da resposta */
			if (resp=='s')
			{
			system("cls");goto Repetir_programa;
			}
			else if (resp!='n')
			{
			goto repeteco;
			}
		  }

	 /* IF para quando acaba as restauracoes */
	 if (cont_rest==(-1)) {

		   /* Limpesa da tela */
		   system("cls");

		   /* Definicao de cor */
		   textcolor(12+BLINK);

		   /* Mensagem */
		   gotoxy(19,10);
		   printf("Acabram-se as Tentativas de restauracao !!");

		   /* Definicao de cor */
		   textcolor(15);

		   /* Pergunta para rejogar */
		   gotoxy(20,14);
		   printf("Deseja jogar novamente ? (s/SIM ou n/NAO)");

		   /* Captura da resposta */
		   repee:

		   /* Captura da resposta */
		   resp=getch();

		   /* Verificacao da resposta */
			if (resp=='s')
			{
			system("cls");goto Repetir_programa;
			}
			else if (resp!='n')
			{
			goto repee;
			}
		  }

	}while(op!=ESC && a>(-1) && cont_rest>(-1));


 /* Restauracao do MODO-DOS */

   textcolor(7);
   printf("X");
   _setcursortype(_NORMALCURSOR);
   system("cls");
   return 0;

}
//----------------------------Funcoes-----------------------------
void posicao(int posnave,int car_nav)
{
  /* Define a cor da nave */
  textcolor(2);

  /* Posiciona a nave */
  gotoxy (posnave,21);

  /* Impresao do caracter da nave */
  printf ("%c",char(car_nav));
}

void tiro(int op,int car_nav, int car_tiro)
{
  /* Variavel contador */
  int i;

  posicao(op,car_nav);
  for (i=20;i>=1;i--)
  {
  /* Animacao do tiro */
  gotoxy (op,i);printf ("%c",char(car_tiro));
  delay (20);
  gotoxy (op,i);printf (" ");

  /* SOM DE TIRO */
  sound(100);
  delay(10);
  nosound();
  delay(5+i);
  }


}

void instrucoes()
{
 /* Variavel contador */
 int i;

 /* Definicao de cor */
 textcolor(14);


 // Moldura das instrucoes

  // Cantos
	 gotoxy(1,22);  printf ("�");
	 gotoxy(80,22); printf ("�");
	 gotoxy(1,24);  printf ("�");
	 gotoxy(80,24); printf ("�");
	 gotoxy(1,23);  printf ("�");
	 gotoxy(80,23); printf ("�");



  // Divisao


   // Tra�o superior
	for (i=2;i<=79;i++) {gotoxy (i,22);printf("�");}

   // Tra�o inferior
	for (i=2;i<=79;i++) {gotoxy (i,24);printf("�");}



  // Arremates


   // Parte Superior
	 gotoxy(10,22); printf ("�");
	 gotoxy(21,22); printf ("�");
	 gotoxy(31,22); printf ("�");
	 gotoxy(38,22); printf ("�");
	 gotoxy(57,22); printf ("�");
	 gotoxy(68,22); printf ("�");


   // Parte Inferior
	 gotoxy(10,24); printf ("�");
	 gotoxy(21,24); printf ("�");
	 gotoxy(31,24); printf ("�");
	 gotoxy(38,24); printf ("�");
	 gotoxy(57,24); printf ("�");
	 gotoxy(68,24); printf ("�");




 // Impresao das instrucoes
	gotoxy(3,23);
	printf("Aperte �%c",char(27));
	printf(" Esquerda�%c",char(26));
	printf(" Direita�%c",char(24));
	printf(" Tiro�%c",char(25));
	printf(" Restaura =");
	gotoxy(57,23);
	printf("�");
	gotoxy(58,23);
	printf("ESC -- Sai");

}

void alvos(int quantidade)
{
 /* Variaveis:contador,posicao X,posicao Y,cor */
 int i,a,b,coloracao;

 /* Definicao da quantidade de alvos */
 quantidade=(30*quantidade);

 /* Inicializacao do randomizador */
 randomize();


 /* LOOP PARA OS ALVOS */
 for (i=0;i<=quantidade;i++)
 {

  /* Randomizacao da posicao dos alvos */
  a=random(81);
  b=random(21);

  /* Definicao da cor do alvo */
  coloracao=random(15);
  textcolor(coloracao);

  /* Se coloracao for preta nao imprimir */
  if (coloracao==1 || coloracao==0) i--;

  /* Redefinicao da posicao caso de ponto fora */
  if (a==0 && b==0) i--;

  /* Escolha do tipo de caracter do alvo */
  if (a % 2==0)
	{
	 /* Posiciona alvo */
	 gotoxy (a,b);
	 /* Imprime alvo cheio */
	 printf ("%c",char(2));
	}


   else {
		 /* Posiciona alvo */
		 gotoxy (a,b);
		 /* Imprime alvo vazado */
		 printf ("%c",char(1));
		}

 }

}

void limpapos(int p)
{
 /* Decisoes para limpar no lugar correto */

 if (p<40)
   {
	p=p+0;gotoxy(p,21);
	printf (" ");
   }

	else {

		  if (p>40) {
					 p=p-0;gotoxy(p,21);
					 printf (" ");
					}

					 else {

						   if (p==40)
							 {
							  gotoxy(40,21);
							  printf (" ");
							 }

						  }
		 }

}

void contpas(int a,int cont_rest)
{
  /* Definicao de cor */
  textcolor(14);

  /* Impressao do LIFE e da contagem do RESTAURA */
  gotoxy (68,23); printf("� TIROS:");
  gotoxy (77,23); printf("   ");
  gotoxy (77,23); printf("%d",a);
  gotoxy (52,23); printf("%d",cont_rest);
}

void intro()
{
  /* Tira cursor */
  _setcursortype(_NOCURSOR);

  /* Definicao de cor */
  textcolor(2);

  /* TITULO */
  gotoxy (3,3);
  printf ("Intrudo��o do jogo N A V E");

  /* Definicao de cor */
  textcolor(12+BLINK);

  /* Tipo de programa */
  gotoxy (3,7);
  printf ("Este jogo � FREEWARE");

  /* Definicao de cor */
  textcolor(2);

  /* REGRAS */
  gotoxy (3,10);
  printf ("Comandos na tela de jogo!!");
  gotoxy (3,12);
  printf ("O objetivo do jogo � destruir os invasores do espa�o");
  gotoxy (3,13);
  printf ("e n�o deixar que seus TIROS acabem.");

  /* Definicao de cor */
  textcolor(13);

  /* AUTOR */
  gotoxy (3,16);
  printf ("Este jogo foi produzido por M�rio Fontes �");

  /* Definicao de cor */
  textcolor(2);

  /* PAUSA !! */
  gotoxy (1,24);
  printf ("Precione algo para continuar ...");

  /* PARADA */
  getch();

  /* SOM DA PARADA */
  som_mov(2300,5700);

}

void restaura(int a,int dificuldade,int car_nav,int cont_rest)
{
  /* Limpa tela*/
  system("cls");

  /* Imprime alvos*/
  alvos(dificuldade);

  /* Imprime a barra de instrucoes */
  instrucoes();

  /* Define cor da nave */
  textcolor(2);

  /* Posiciona nave */
  gotoxy (40,21); printf ("%c",char(car_nav));

  /* Contador de passos */
  contpas(a,cont_rest);
}

void som_mov(int inicio,int fim)
{

 /* Variavel do contador */
 int x;

 /* Tipos de som */

 //|------------------------------|
 //|INICIO   FIM                  |
 //|                              |
 //|11000 a 11010 som leve.       |
 //|1000  a 2000  som chato.      |
 //|3000  a 6000  som piu.        |
 //|100   a 1000  som WAP.        |
 //|10    a 100   som TUM-TUM.    |
 //|500   a 10000 som WAIIIIP.    |
 //|300   a 700   som COOL(1).    |
 //|2300  a 5700  som especial(1) |
 //|------------------------------|


 /* LOOP DO SOM */
 for(x=inicio;x<=fim;x++)
 {
  sound(x);
  delay(1/2);
 }
 nosound();

}


int esc_dificuldade()
{
 /* Variavel da captura */
 int cap_dif;

 /* Limpa a tela */
 system("cls");

 /* Definicao de cor */
 textcolor(12);


 /* TEXTO */

  /* Titulo */
   gotoxy(17,7);
   printf("�� Escolha o nivel de dificuldade desejada ��");

  /* Escolhas */

   /* Definicao de cor */
   textcolor(15);

   gotoxy(5,12);
   printf("1 - DIFICIL");

   gotoxy(5,13);
   printf("2 - MEDIO");

   gotoxy(5,14);
   printf("3 - FACIL");


  /* Captura do resultado */

   /* Definicao de cor */
   textcolor(13);

   gotoxy(5,18);
   printf(">");
   cin >> cap_dif;

   /* Validade da opcao e define com DEFAULT */
   if(cap_dif<1 || cap_dif>3) cap_dif=1;

  /* SOM DA ESCOLHA */
   som_mov(500,10000);

  /* Saida do resultado */
  return cap_dif;

}

int defini_tiros(int dificuldade)
{
 int a;
   switch(dificuldade)
   {
	case 1:	a=(dificuldade*31);break;
	case 2: a=(dificuldade*30);a=a-10;break;
	case 3: a=(dificuldade*28);;break;
   }
 return a;
}

int def_nave()
{
 int cap_dif;
 system("cls");


 /* TEXTO */


  /* Titulo */
   gotoxy(17,7);
   printf("�� Escolha a nave desejada ��");


  /* Escolhas */

   /* Definicao de cor */
   textcolor(15);

   gotoxy(5,11);
   printf("1 - %c",char(29));

   gotoxy(5,12);
   printf("2 - %c",char(127));

   gotoxy(5,13);
   printf("3 - %c",char(30));

   gotoxy(5,14);
   printf("4 - %c",char(190));

   gotoxy(5,15);
   printf("5 - %c",char(21));


  /* Captura do resultado */

   /* Definicao de cor */
   textcolor(13);

   /* PROMPT de espera */

	 gotoxy(5,18);
	 printf(">");

	 /* Captura da opcao */
	 cin >> cap_dif;

   /* Validade da opcao e define com DEFAULT */
   if(cap_dif<1 || cap_dif>5) cap_dif=2;

  /* SOM DA ESCOLHA */
   som_mov(500,10000);


  /* Definicao do caracter */
   switch(cap_dif)
   {
	case 1:cap_dif=29;break;
	case 2:cap_dif=127;break;
	case 3:cap_dif=30;break;
	case 4:cap_dif=190;break;
	case 5:cap_dif=21;break;
   }

  /* Saida do resultado */
  return cap_dif;
}

int def_tiro()
{
 int cap_dif;
 system("cls");


 /* TEXTO */


  /* Titulo */
   gotoxy(17,7);
   printf("�� Escolha o tipo de tiro desejado ��");


  /* Escolhas */

   /* Definicao de cor */
   textcolor(15);

   gotoxy(5,11);
   printf("1 - %c",char(46));

   gotoxy(5,12);
   printf("2 - %c",char(33));

   gotoxy(5,13);
   printf("3 - %c",char(58));

   gotoxy(5,14);
   printf("4 - %c",char(124));

   gotoxy(5,15);
   printf("5 - %c",char(64));


  /* Captura do resultado */

   /* Definicao de cor */
   textcolor(13);


   /* PROMPT de espera */

	 gotoxy(5,18);
	 printf(">");

	 /* Captura da opcao */
	 cin >> cap_dif;

   /* Validade da opcao e define com DEFAULT */
   if(cap_dif<1 || cap_dif>5) cap_dif=2;


   /* SOM DA ESCOLHA */
   som_mov(500,10000);


  /* Definicao do caracter */
   switch(cap_dif)
   {
	case 1:cap_dif=46;break;
	case 2:cap_dif=33;break;
	case 3:cap_dif=58;break;
	case 4:cap_dif=124;break;
	case 5:cap_dif=64;break;
   }


  /* Saida do resultado */
  return cap_dif;
}